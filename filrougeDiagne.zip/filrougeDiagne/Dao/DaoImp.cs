﻿using FilRouge.Metiers.ClassesMetiers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FilRouge.Metiers.ClassesModeles;

namespace FilRouge.Dao
{
    class DaoImp: IDao
    {

        //methodes dao echanges vers la bdd deja implémentes


       

        public ICollection<Utilisateur> FindAllClient()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Utilisateurs.ToList();


            }
        }
     
      
        public Role AjouterUnRole(Role unRole)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.RoleUtilisateurs.Add(unRole);
                edb.SaveChanges();
                return unRole;
            }
        }


        public ICollection<Role> findAllRole()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.RoleUtilisateurs.ToList();
            }
        }

        public Role findRole(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.RoleUtilisateurs.Find(id);

            }
        }

        public void ModifierUnRole(Role unRole)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Entry(unRole).State = EntityState.Modified;
                edb.SaveChanges();
            }
        }


        public void SupprimerUnRole(int idRole)
        {
            using (var edb = new EVentesDBcontext())
            {
                Role r = edb.RoleUtilisateurs.Find(idRole);
                edb.RoleUtilisateurs.Remove(r);
                edb.SaveChanges();
            }
        }

        public ICollection<Role> findRoleById(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = from p in edb.RoleUtilisateurs
                          where p.RoleId==id
                          select p;
                return req.ToList();
            }
        }

        public Adresse AjouterUneAdresse(Adresse monAdresse)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Adresses.Add(monAdresse);
                edb.SaveChanges();
                return monAdresse;
            }
        }



        public Adresse findAdresse(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Adresses.Find(id);

            }
        }

        public void ModifierUneAdresse(Adresse monAdresse)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Entry(monAdresse).State = EntityState.Modified;
                edb.SaveChanges();
            }
        }

        public void SupprimerUneAdresse(int monAdresse)
        {
            using (var edb = new EVentesDBcontext())
            {
                Adresse r = edb.Adresses.Find(monAdresse);
                edb.Adresses.Remove(r);
                edb.SaveChanges();
            }
        }

        public ICollection<Adresse> findAllAdresse()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Adresses.ToList();
            }
        }

        public ICollection<Adresse> findAdresseById(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = from p in edb.Adresses
                          where p.AdresseId == id
                          select p;
                return req.ToList();
            }
        }
        public ICollection<Utilisateur> findAllAdministrateurs()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Utilisateurs.ToList();
            }
        }

        public Utilisateur AjouterUnAdministrateur(Administrateur monAdmin)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Utilisateurs.Add(monAdmin);
                edb.SaveChanges();
                return monAdmin;
            }
        }

        public Utilisateur findAdministrateur(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Utilisateurs.Find(id);

            }
        }

        public void ModifierUnAdministrateur(Administrateur monAdmin)
        {

            using (var edb = new EVentesDBcontext())
            {
                edb.Entry(monAdmin).State = EntityState.Modified;
                edb.SaveChanges();
            }
        }

        public ICollection<Utilisateur> findAdministrateurById(int id)
        {

            using (var edb = new EVentesDBcontext())
            {
                var req = from p in edb.Utilisateurs
                          where p.UtilisateurId == id
                          select p;
                return req.ToList();
            }
        }

        public ICollection<AdministrateurModele> findAllAdministrateurModele()
        {
            using (var edb = new EVentesDBcontext())
            {
                return ( from u in edb.Administrateurs
                          join r in edb.RoleUtilisateurs on u.RoleId equals r.RoleId
                          join a in edb.Adresses on u.AdresseId equals a.AdresseId
                          select new AdministrateurModele
                          {
                              Nom=u.Nom,
                              Prenom=u.Prenom,
                              DateOfBirth=u.DateOfBirth,
                              Identifiant=u.Identifiant,
                              Email=u.Email,
                              Password=u.Password,
                              MdpConfirm=u.MdpConfirm,
                              Droit=r.Droit,
                              NomDeRue=a.NomDeRue,
                              CodePostal=a.CodePostal,
                              Ville=a.Ville,
                              Pays=a.Pays
                          }).ToList();
            }
        }

        public Administrateur LoginAdmin(Administrateur a)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = edb.Administrateurs.FirstOrDefault
                    (u => u.Identifiant == a.Identifiant && u.Password == a.Password);
                return req;
            }
        }

        public Utilisateur AjouterUnClient(ClientModele cm)
        {
            using (var edb = new EVentesDBcontext())
            {
                //on recupere les données du client a travers le modele puis on les  affecte au client


                //on cree une adresse et on affecte les parametres tapée par l utilisateur
                Adresse a = new Adresse();
                a.NomDeRue = cm.NomDeRue;
                a.CodePostal = cm.CodePostal;
                a.Ville = cm.Ville;
                a.Pays = cm.Pays;
                edb.Adresses.Add(a);
                edb.SaveChanges();
                // chargement des valeurs non enregistrées par l admin
                Client monClient = new Client();
                monClient.AdresseId = a.AdresseId;
                monClient.RoleId = 3;
                monClient.Anniversaire = false;
                monClient.CompteActif = true;
                monClient.CompteASupprimer = false;
                monClient.DateStartTime = DateTime.Now;

                //chargement des valeurs recupérees par clientmodele
                monClient.Nom = cm.Nom;
                monClient.Prenom = cm.Prenom;
                monClient.Identifiant = cm.Identifiant;
                monClient.Password = cm.Password;
                monClient.MdpConfirm = cm.MdpConfirm;
                monClient.Email = cm.Email;
                monClient.DateOfBirth = cm.DateOfBirth;
                
                // on charge client en bdd
                edb.Utilisateurs.Add(monClient);
                edb.SaveChanges();
                return monClient;
            }
        }

        public ICollection<ClientModele> findAllClientModele()
        {
            using (var edb = new EVentesDBcontext())
            {
                return (from u in edb.Clients
                        join r in edb.RoleUtilisateurs on u.RoleId equals r.RoleId
                        join a in edb.Adresses on u.AdresseId equals a.AdresseId
                        select new ClientModele
                        {
                            Nom = u.Nom,
                            Prenom = u.Prenom,
                            DateOfBirth = u.DateOfBirth,
                            Identifiant = u.Identifiant,
                            Email = u.Email,
                            Password = u.Password,
                            MdpConfirm = u.MdpConfirm,
                            Droit = r.Droit,
                            NomDeRue = a.NomDeRue,
                            CodePostal = a.CodePostal,
                            Ville = a.Ville,
                            Pays = a.Pays,
                            Anniversaire=u.Anniversaire,
                            DateStartTime=u.DateStartTime,
                            NumeroCarteFidelite=u.NumeroCarteFidelite,
                            NbPoints=u.NbPoints,
                            CompteActif=u.CompteActif,
                            CompteASupprimer=u.CompteASupprimer
                        }).ToList();
            }
        }



        public Client LoginClient(Client c)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = edb.Clients.FirstOrDefault
                    (u => u.Identifiant == c.Identifiant && u.Password == c.Password);
                return req;
            }
        }


        public Utilisateur findClient(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Clients.Find(id);

            }
        }

        public void ModifierUnClient(Client unClient)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Entry(unClient).State = EntityState.Modified;
                edb.SaveChanges();
            }
        }

        public ICollection<Client> findAllClient()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Clients.ToList();
            }
        }

        public void SupprimerUnAdministrateur(int monAdmin)
        {
            using (var edb = new EVentesDBcontext())
            {
                Utilisateur u = edb.Utilisateurs.Find(monAdmin);
                edb.Utilisateurs.Remove(u);
                edb.SaveChanges();
            }
        }


        public void SupprimerUnClient(int monClient)
        {
            using (var edb = new EVentesDBcontext())
            {
                Utilisateur u = edb.Utilisateurs.Find(monClient);
                edb.Utilisateurs.Remove(u);
                edb.SaveChanges();
            }
        }

        public ICollection<Utilisateur> findClientById(int id)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = from p in edb.Utilisateurs
                          where p.UtilisateurId == id
                          select p;
                return req.ToList();
            }
        }

        public Produit AjouterUnProduit(Produit monProduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Produits.Add(monProduit);
                edb.SaveChanges();
                return monProduit;
            }
        }

      

        public ICollection<Produit> findAll()
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Produits.ToList();
            }
        }




        void supprimerUnProduit(int Idproduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Produits.Remove(findProduit(Idproduit));
                edb.SaveChanges();

            }

        }



        public ICollection<Produit> findProductByName(string nom)
        {
            using (var edb = new EVentesDBcontext())
            {
                // return edb.Produits.Where(p => p.Nom == nom).ToList();
                var req = from p in edb.Produits
                          where p.Nom.Contains(nom)
                          select p;
                return req.ToList();
            }
        }
        public Produit findProduit(int Idproduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                return edb.Produits.Find(Idproduit);

            }
        }

        public void ModifierUnProduit(Produit monProduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Entry(monProduit).State = EntityState.Modified;
                edb.SaveChanges();


            }
        }

        public void SupprimerUnProduit(int Idproduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                Produit p = edb.Produits.Find(Idproduit);
                edb.Produits.Remove(p);
                edb.SaveChanges();


            }
        }

        public Utilisateur LoginUsers(Utilisateur ul)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = edb.Utilisateurs.FirstOrDefault
                    (u => u.Identifiant == ul.Identifiant && u.Password == ul.Password);
                return req;
            }
        }

        public  ICollection<Role> getRole(Utilisateur u)
        {
            using (var edb = new EVentesDBcontext())
            {
                var req = from r in edb.RoleUtilisateurs
                          where (u.RoleId == r.RoleId)
                          select r;
                return req.ToList();
            }
             
        }


        /*********************************************************************************************************/





        public AdresseDeFacturation AjouterAdrFacturation(AdresseDeFacturation monAdrFac)
        {
            return monAdrFac;

        }

        public AdresseLivraison AjouterAdrLivraison(AdresseLivraison monAdrLivr)
        {
            return monAdrLivr;

        }
        public Abonnement AjouterAbonnement(Abonnement monAbonnement)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Abonnements.Add(monAbonnement);
                edb.SaveChanges();
                return monAbonnement;
            }
        }

        public AvisProduit AjouterAvis(AvisProduit monAvis)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.AvisProduitS.Add(monAvis);
                edb.SaveChanges();
                return monAvis;
            }
        }

        public BonDeLivraison AjouterBonLivr(BonDeLivraison monBonDeLivr)
        {
            return monBonDeLivr;
        }

        public CarteBancaire AjouterCarteBancaire(CarteBancaire maCb)
        {
           
                return maCb;
            
        }

        public Catalogue AjouterCatalogue(Catalogue monCatalogue)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Catalogues.Add(monCatalogue);
                edb.SaveChanges();
                return monCatalogue;
            }
        }

        public Cheque AjouterCheque(Cheque monChequier)
        {
          
                return monChequier;
            
        }

        public Client AjouterClient(Client monClient)
        {
         
                return monClient;
            
        }

        public Commande AjouterCommande(Commande maCommande)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Commandes.Add(maCommande);
                edb.SaveChanges();
                return maCommande;
            }
        }

        public Facturation AjouterFacturation(Facturation mafacture)
        {
          
                return mafacture;
            
        }

        public LigneDeCommande AjouterLigneDeCommande(LigneDeCommande meslignes)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.LigneCommandes.Add(meslignes);
                edb.SaveChanges();
                return meslignes;
            }
        }

        public Produit AjouterProduit(Produit monProduit)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Produits.Add(monProduit);
                edb.SaveChanges();
                return monProduit;
            }
        }

        public Promotion AjouterUnePromotion(Promotion maPromo)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Mespromos.Add(maPromo);
                edb.SaveChanges();
                return maPromo;
            }
        }

        public Paiement AjouterUnPaiement(Paiement monPaiement)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Paiements.Add(monPaiement);
                edb.SaveChanges();
                return monPaiement;
            }
        }

        public Panier AjouterUnPanier(Panier monPanier)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Paniers.Add(monPanier);
                edb.SaveChanges();
                return monPanier;
            }
        }

        public ProduitsConsulte AjouterunProdVu(ProduitsConsulte monProdVu)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.ProduitConsultes.Add(monProdVu);
                edb.SaveChanges();
                return monProdVu;
            }
        }

        public Utilisateur AjouterUnUser(Utilisateur user)
        {
            using (var edb = new EVentesDBcontext())
            {
                edb.Utilisateurs.Add(user);
                edb.SaveChanges(); 
                return user;
            }
        }

        public Commande PayerUneCommande(Commande maCommande)
        {
            
                return maCommande;
            
        }






        public bool AjouterCarteDeFidelite()
        {
    
                return true;
            
        }


      

        public bool creationCompteClient()
        {
            //il fau enregistrer les donnnes saisies par  l user




            return true;
        }

       

        public Client ModiferClient(Client monClient)
        {
            throw new NotImplementedException();
        }

        public Administrateur ModifierAdmin(Administrateur monAdmin)
        {
            throw new NotImplementedException();
        }

       

        public Catalogue MAJCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

        public Produit ModifierProduit(Produit monProduit)
        {
            throw new NotImplementedException();
        }

        public Commande ModifierCommande(Commande maCommande)
        {
            throw new NotImplementedException();
        }

        public LigneDeCommande ModifierLigneDeCommande()
        {
            throw new NotImplementedException();
        }

        public Panier ModifierUnPanier(Panier monPanier)
        {
            throw new NotImplementedException();
        }

        public Promotion ModifierUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }

        public AdresseDeFacturation ModifierAdrFacturation(AdresseDeFacturation monAdrFac)
        {
            throw new NotImplementedException();
        }

        public AdresseLivraison ModifierAdrLivraison(AdresseLivraison monAdrLivr)
        {
            throw new NotImplementedException();
        }

        public BonDeLivraison ModifierBonLivr(BonDeLivraison monBonDeLivr)
        {
            throw new NotImplementedException();
        }

        public Abonnement ModifierAbonnement(Abonnement monAbonnement)
        {
            throw new NotImplementedException();
        }

        public ProduitsConsulte ModifierunProdVu(ProduitsConsulte monProdVu)
        {
            throw new NotImplementedException();
        }

        public AvisProduit ModifierAvis(AvisProduit monAvis)
        {
            throw new NotImplementedException();
        }

       

        public Client SupprimerClient(Client monClient)
        {
            throw new NotImplementedException();
        }

        public Administrateur SupprimerAdmin(Administrateur monAdmin)
        {
            throw new NotImplementedException();
        }

       

        public Catalogue SupprimerCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

        public Produit SupprimerProduit(Produit monProduit)
        {
            throw new NotImplementedException();
        }

        public Commande SupprimerCommande(Commande maCommande)
        {
            throw new NotImplementedException();
        }

        public LigneDeCommande SupprimerLigneDeCommande()
        {
            throw new NotImplementedException();
        }

        public Panier SupprimerUnPanier(Panier monPanier)
        {
            throw new NotImplementedException();
        }

        public Promotion SupprimerUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }

        public AdresseDeFacturation SupprimerAdrFacturation(AdresseDeFacturation monAdrFac)
        {
            throw new NotImplementedException();
        }

        public AdresseLivraison SupprimerAdrLivraison(AdresseLivraison monAdrLivr)
        {
            throw new NotImplementedException();
        }

        public BonDeLivraison SupprimerBonLivr(BonDeLivraison monBonDeLivr)
        {
            throw new NotImplementedException();
        }

        public Abonnement SupprimerAbonnement(Abonnement monAbonnement)
        {
            throw new NotImplementedException();
        }

        public ProduitsConsulte ModifunProdVu(ProduitsConsulte monProdVu)
        {
            throw new NotImplementedException();
        }

        public AvisProduit SupprimerAvis(AvisProduit monAvis)
        {
            throw new NotImplementedException();
        }

        public Commande PayerUneCommande()
        {
            throw new NotImplementedException();
        }

        public void AfficheUser(Utilisateur userAAfficher)
        {
            throw new NotImplementedException();
        }

        public void AfficheAllUser(ICollection<Utilisateur> userAllAAfficher)
        {
            throw new NotImplementedException();
        }

    













































        //public  Adresse ModifierlAdr(Adresse monAdresse)
        // {



        // }

        // public Client ModiferClient(Client monClient)
        // {
        //     return monClient;
        // }

        // public Administrateur ModifierAdmin(Administrateur monAdmin)
        // {
        //     throw new NotImplementedException();
        // }

        // public Role ModifierUnRole(Role unRole)
        // {
        //     throw new NotImplementedException();
        // }

        // public Catalogue MAJCatalogue(Catalogue monCatalogue)
        // {
        //     throw new NotImplementedException();
        // }

        // public Produit ModifierProduit(Produit monProduit)
        // {
        //     throw new NotImplementedException();
        // }

        // public Commande ModifierCommande(Commande maCommande)
        // {
        //     throw new NotImplementedException();
        // }

        // public LigneDeCommande ModifierLigneDeCommande()
        // {
        //     throw new NotImplementedException();
        // }

        // public Panier ModifierUnPanier(Panier monPanier)
        // {
        //     throw new NotImplementedException();
        // }

        // public Promotion ModifierUnePromotion(Promotion maPromo)
        // {
        //     throw new NotImplementedException();
        // }

        // public AdresseDeFacturation ModifierAdrFacturation(AdresseDeFacturation monAdrFac)
        // {
        //     throw new NotImplementedException();
        // }

        // public AdresseLivraison ModifierAdrLivraison(AdresseLivraison monAdrLivr)
        // {
        //     throw new NotImplementedException();
        // }

        // public BonDeLivraison ModifierBonLivr(BonDeLivraison monBonDeLivr)
        // {
        //     throw new NotImplementedException();
        // }

        // public Abonnement ModifierAbonnement(Abonnement monAbonnement)
        // {
        //     throw new NotImplementedException();
        // }

        // public ProduitsConsulte ModifierunProdVu(ProduitsConsulte monProdVu)
        // {
        //     throw new NotImplementedException();
        // }

        // public AvisProduit ModifierAvis(AvisProduit monAvis)
        // {
        //     throw new NotImplementedException();
        // }

        // public Adresse SupprimerAdresse(Adresse monAdresse)
        // {
        //     throw new NotImplementedException();
        // }

        // public Client SupprimerClient(Client monClient)
        // {
        //     throw new NotImplementedException();
        // }

        // public Administrateur SupprimerAdmin(Administrateur monAdmin)
        // {
        //     throw new NotImplementedException();
        // }

        // public Role SupprimerUnRole(Role unRole)
        // {
        //     throw new NotImplementedException();
        // }

        // public Catalogue SupprimerCatalogue(Catalogue monCatalogue)
        // {
        //     throw new NotImplementedException();
        // }

        // public Produit SupprimerProduit(Produit monProduit)
        // {
        //     throw new NotImplementedException();
        // }

        // public Commande SupprimerCommande(Commande maCommande)
        // {
        //     throw new NotImplementedException();
        // }

        // public LigneDeCommande SupprimerLigneDeCommande()
        // {
        //     throw new NotImplementedException();
        // }

        // public Panier SupprimerUnPanier(Panier monPanier)
        // {
        //     throw new NotImplementedException();
        // }

        // public Promotion SupprimerUnePromotion(Promotion maPromo)
        // {
        //     throw new NotImplementedException();
        // }

        // public AdresseDeFacturation SupprimerAdrFacturation(AdresseDeFacturation monAdrFac)
        // {
        //     throw new NotImplementedException();
        // }

        // public AdresseLivraison SupprimerAdrLivraison(AdresseLivraison monAdrLivr)
        // {
        //     throw new NotImplementedException();
        // }

        // public BonDeLivraison SupprimerBonLivr(BonDeLivraison monBonDeLivr)
        // {
        //     throw new NotImplementedException();
        // }

        // public Abonnement SupprimerAbonnement(Abonnement monAbonnement)
        // {
        //     throw new NotImplementedException();
        // }

        // public ProduitsConsulte ModifunProdVu(ProduitsConsulte monProdVu)
        // {
        //     throw new NotImplementedException();
        // }

        // public AvisProduit SupprimerAvis(AvisProduit monAvis)
        // {
        //     throw new NotImplementedException();
        // }

        // public void AfficheUser(Utilisateur userAAfficher)
        // {
        //     throw new NotImplementedException();
        // }









        //public Produit AjouterUnProduit(Produit monProduit)
        //{
        //    using (var edb = new EVentesDBcontext())
        //    {
        //        edb.Produits.Add(monProduit);
        //        edb.SaveChanges();
        //        return monProduit;
        //    }
        //}

        //public Produit Update(Produit unProduit)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Produits.Add(unProduit);
        //        edb.SaveChanges();
        //        return unProduit;
        //    }
        //}

        //public ICollection<Produit> findAll()
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Produits.ToList();


        //    }
        //}




        //void supprimerUnProduit(int Idproduit)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Produits.Remove(findProduit(Idproduit));
        //        edb.SaveChanges();

        //    }

        //}



        //public ICollection<Produit> findProductByName(string nom)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        // return edb.Produits.Where(p => p.Nom == nom).ToList();
        //        var req = from p in edb.Produits
        //                  where p.Nom.Contains(nom)
        //                  select p;
        //        return req.ToList();
        //    }
        //}



        //public Categorie AjouterUneCategorie(Categorie maCategorie)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Categories.Add(maCategorie);
        //        edb.SaveChanges();
        //        return maCategorie;
        //    }
        //}

        //public Magasin AjouterunMagasin(Magasin monMagasin)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Magasins.Add(monMagasin);
        //        edb.SaveChanges();
        //        return monMagasin;
        //    }
        //}






        //public void ModifierUneCategorie(Categorie maCategorie)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Entry(maCategorie).State = EntityState.Modified;
        //        edb.SaveChanges();


        //    }
        //}

        //public Categorie findCategorie(int IdCategorie)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Categories.Find(IdCategorie);

        //    }
        //}

        //public Produit findProduit(int Idproduit)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Produits.Find(Idproduit);

        //    }
        //}

        //public void SupprimerUneCategorie(int IdCategorie)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        Categorie c = edb.Categories.Find(IdCategorie);
        //        edb.Categories.Remove(c);
        //        edb.SaveChanges();


        //    }
        //}

        //public void ModifierUnProduit(Produit monProduit)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Entry(monProduit).State = EntityState.Modified;
        //        edb.SaveChanges();


        //    }
        //}

        //public void SupprimerUnProduit(int Idproduit)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        Produit p = edb.Produits.Find(Idproduit);
        //        edb.Produits.Remove(p);
        //        edb.SaveChanges();


        //    }
        //}




        //public ICollection<Categorie> findAllCategorie()
        //{



        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Categories.ToList();


        //    }
        //}

        //public ICollection<Magasin> findAllMagasin()
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Magasins.ToList();


        //    }
        //}

        //public Magasin findMagasin(int IdMagasin)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        return edb.Magasins.Find(IdMagasin);

        //    }
        //}

        //public ICollection<Magasin> findMagasinByName(string nomDuMagasin)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        // return edb.Produits.Where(p => p.Nom == nom).ToList();
        //        var req = from p in edb.Magasins
        //                  where p.nomMagasin.Contains(nomDuMagasin)
        //                  select p;
        //        return req.ToList();
        //    }
        //}

        //public void SupprimerUnMagasin(int IdMagasin)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        Magasin m = edb.Magasins.Find(IdMagasin);
        //        edb.Magasins.Remove(m);
        //        edb.SaveChanges();


        //    }
        //}

        //public void ModifierUnMagasin(Magasin monMagasin)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.Entry(monMagasin).State = EntityState.Modified;
        //        edb.SaveChanges();


        //    }
        //}

        //public ICollection<ProduitCatModel> findAllProduitandCat()
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        var req = from p in edb.Produits
        //                  join c in edb.Categories
        //                  on p.CategorieId equals c.CategorieId
        //                  select new ProduitCatModel
        //                  {
        //                      ProduitId = p.ProduitId,
        //                      NomProduit = p.Nom,
        //                      Prix = p.Prix,
        //                      Description = p.Description,
        //                      NomCategorie = c.NomCategorie
        //                  };
        //        return req.ToList();
        //    }
        //}

        //public Client LoginUser(Client c)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        var req = edb.Clients.FirstOrDefault
        //            (u => u.Login == c.Login && u.MotdePasse == c.MotdePasse);
        //        return req;
        //    }

        //}

        //public MagasinProduit AjouterProduitAMagasin(MagasinProduit mp)
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        edb.UnMagasinDeProduit.Add(mp);
        //        edb.SaveChanges();
        //        return mp;
        //    }
        //}

        //public ICollection<MagasinProduitModele> findAllMagasinProduit()
        //{
        //    using (var edb = new ElementContext())
        //    {
        //        var req = from p in edb.Produits
        //                  join mp in edb.UnMagasinDeProduit
        //                  on p.ProduitId equals mp.ProduitId
        //                  join m in edb.Magasins
        //                  on mp.MagasinId equals m.MagasinId

        //                  select new MagasinProduitModele
        //                  {
        //                      NomMagasin = m.nomMagasin,
        //                      NomProduit = p.Nom,
        //                      Stock = mp.Stock
        //                  };
        //        return req.ToList();
        //    }
        //}

    }
}

