﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Dao
{
   public class EVentesDBcontext:DbContext
    {

        public EVentesDBcontext() :base("FilRouge")
        {

        }


        public DbSet<Utilisateur> Utilisateurs                { get; set; }
        public DbSet<Catalogue>   Catalogues                  { get; set; }
        public DbSet<Produit>     Produits                    { get; set; }
        public DbSet<Adresse>     Adresses                    { get; set; }
        public DbSet<Commande>    Commandes                   { get; set; }     
        public DbSet<ProduitsConsulte> ProduitConsultes       { get; set; }
        public DbSet<AvisProduit> AvisProduitS                { get; set; }
        public DbSet<Panier> Paniers                          { get; set; }  
        public DbSet<LigneDeCommande> LigneCommandes          { get; set; }
        public DbSet<Paiement> Paiements                      { get; set; }
        public DbSet<Abonnement> Abonnements                  { get; set; }
        public DbSet<BonDeLivraison> BonDeLivraisons          { get; set; }
        public DbSet<Promotion> Mespromos                     { get; set; }
        public DbSet<Role> RoleUtilisateurs                   { get; set; }
        public DbSet<Administrateur> Administrateurs          { get; set; }
        public DbSet<Client> Clients                          { get; set; }
    }
}

