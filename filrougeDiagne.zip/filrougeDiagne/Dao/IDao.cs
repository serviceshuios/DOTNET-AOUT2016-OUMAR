﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FilRouge.Dao
{
    public interface IDao
    {
       


       //metiers Users  Dao ajoutés 

       

        ICollection<Utilisateur> FindAllClient();

        Adresse AjouterUneAdresse(Adresse monAdresse);


        //metiers Admin  Dao ajoutés 

        Role AjouterUnRole(Role unRole);

        ICollection<Role> findAllRole();

         Role findRole(int id);

        void ModifierUnRole(Role unRole);
        void SupprimerUnRole(int idRole);
        ICollection<Role> findRoleById(int id);

       
        Adresse findAdresse(int id);

        void ModifierUneAdresse(Adresse monAdresse);
        void SupprimerUneAdresse(int monAdresse);
        ICollection<Adresse> findAllAdresse();

        ICollection<Adresse> findAdresseById(int id);
        ICollection<Utilisateur> findAllAdministrateurs();
        ICollection<AdministrateurModele> findAllAdministrateurModele();

        Utilisateur AjouterUnAdministrateur(Administrateur monAdmin);

        Utilisateur findAdministrateur(int id);
        void ModifierUnAdministrateur(Administrateur monAdmin);

        ICollection<Utilisateur> findAdministrateurById(int id);

        void SupprimerUnAdministrateur(int monAdmin);

        Administrateur LoginAdmin(Administrateur a);

        Utilisateur AjouterUnClient(ClientModele cm);
        ICollection<ClientModele> findAllClientModele();
        Client LoginClient(Client c);
        Utilisateur findClient(int id);

        void ModifierUnClient(Client unClient);

        ICollection<Client> findAllClient();

        void SupprimerUnClient(int monClient);

        ICollection<Utilisateur> findClientById(int id);
        Produit AjouterUnProduit(Produit monProduit);
        ICollection<Produit> findAll();
        Produit findProduit(int Idproduit);
        void SupprimerUnProduit(int Idproduit);
        void ModifierUnProduit(Produit monProduit);

        ICollection<Produit> findProductByName(string nom);

        Utilisateur LoginUsers(Utilisateur u);
        ICollection<Role> getRole(Utilisateur u);



        /**************************************************************************************************/

        Produit AjouterProduit(Produit monProduit);
        Utilisateur AjouterUnUser(Utilisateur user);
       

        Catalogue AjouterCatalogue(Catalogue monCatalogue);
        Commande AjouterCommande(Commande maCommande);
      
        LigneDeCommande AjouterLigneDeCommande(LigneDeCommande mesLignes);
        Paiement AjouterUnPaiement(Paiement monPaiement);
        Panier AjouterUnPanier(Panier monPanier);
        Promotion AjouterUnePromotion(Promotion maPromo);

        AdresseDeFacturation AjouterAdrFacturation(AdresseDeFacturation monAdrFac);
        AdresseLivraison AjouterAdrLivraison(AdresseLivraison monAdrLivr);
        Facturation AjouterFacturation(Facturation mafacture);
        CarteBancaire AjouterCarteBancaire(CarteBancaire maCb);
        Cheque AjouterCheque(Cheque monChequier);
        BonDeLivraison AjouterBonLivr(BonDeLivraison monBonDeLivr);


        Abonnement AjouterAbonnement(Abonnement monAbonnement);
        bool AjouterCarteDeFidelite();
        ProduitsConsulte AjouterunProdVu(ProduitsConsulte monProdVu);
        AvisProduit AjouterAvis(AvisProduit monAvis);


        //methodes modifier


      
     
       



        Catalogue MAJCatalogue(Catalogue monCatalogue);
        Produit ModifierProduit(Produit monProduit);
        Commande ModifierCommande(Commande maCommande);
        LigneDeCommande ModifierLigneDeCommande();
        Panier ModifierUnPanier(Panier monPanier);
        Promotion ModifierUnePromotion(Promotion maPromo);

        AdresseDeFacturation ModifierAdrFacturation(AdresseDeFacturation monAdrFac);
        AdresseLivraison ModifierAdrLivraison(AdresseLivraison monAdrLivr);


        BonDeLivraison ModifierBonLivr(BonDeLivraison monBonDeLivr);


        Abonnement ModifierAbonnement(Abonnement monAbonnement);
        ProduitsConsulte ModifierunProdVu(ProduitsConsulte monProdVu);
        AvisProduit ModifierAvis(AvisProduit monAvis);


        //methodes supprimer


       
        Client SupprimerClient(Client monClient);
        
     


        Catalogue SupprimerCatalogue(Catalogue monCatalogue);
        Produit SupprimerProduit(Produit monProduit);
        Commande SupprimerCommande(Commande maCommande);
        LigneDeCommande SupprimerLigneDeCommande();
        Panier SupprimerUnPanier(Panier monPanier);
        Promotion SupprimerUnePromotion(Promotion maPromo);

        AdresseDeFacturation SupprimerAdrFacturation(AdresseDeFacturation monAdrFac);
        AdresseLivraison SupprimerAdrLivraison(AdresseLivraison monAdrLivr);


        BonDeLivraison SupprimerBonLivr(BonDeLivraison monBonDeLivr);


        Abonnement SupprimerAbonnement(Abonnement monAbonnement);
        ProduitsConsulte ModifunProdVu(ProduitsConsulte monProdVu);
        AvisProduit SupprimerAvis(AvisProduit monAvis);


        // actions
       
        bool creationCompteClient();
        Commande PayerUneCommande();
        void  AfficheUser(Utilisateur userAAfficher);

        void AfficheAllUser(ICollection<  Utilisateur> userAllAAfficher);




    }
}
