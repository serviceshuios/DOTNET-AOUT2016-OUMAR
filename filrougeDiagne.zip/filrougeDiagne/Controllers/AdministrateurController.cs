﻿using FilRouge.Metiers.InterfacesMetiers;
using FilRouge.Metiers.ClassesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FilRouge.Metiers.ClassesModeles;

namespace FilRouge.Controllers
{
    public class AdministrateurController : Controller
    {

        public ImetiersAdmin Imetiers = new MetersImpAdmin();
        // GET: Administrateur

       
        public ActionResult Index()
        {       
                ICollection<AdministrateurModele> res = Imetiers.findAllAdministrateurModele();
                return View(res);     
        }

        // vue d' affichage du formulaire d'ajout des roles
        public ActionResult AjouterUnAdministrateur()
        {   
                return View();       
        }

        [HttpPost]
        public ActionResult AjouterUnAdministrateur(Administrateur unAdmin)
        {
            if (ModelState.IsValid)
            {
                Imetiers.AjouterUnAdministrateur(unAdmin);
                return RedirectToAction("Index");
            }

            else
            {
                return View(unAdmin);
            }
        }

        public ActionResult ModifierUnAdministrateur(int id)
        {

            Utilisateur monAdmin = Imetiers.findAdministrateur(id);

            return View(monAdmin);
           
        }

        [HttpPost]
        public ActionResult ModifierUnAdministrateur(Administrateur a)
        {

            Imetiers.ModifierUnAdministrateur(a);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("Index");
        }


        public ActionResult RechercherUnAdministrateur()
        {

           
            ICollection<Utilisateur> users = Imetiers.findAllAdministrateurs();
            return View(users);

        }

        [HttpPost]
        public ActionResult RechercherUnAdministrateur(int UtilisateurId)
        {

            ICollection<Utilisateur> product = Imetiers.findAdministrateurById(UtilisateurId);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return View(product);
        }

        public ActionResult SupprimerUnAdministrateur(int id)
        {
            Imetiers.SupprimerUnAdministrateur(id);
            return RedirectToAction("Index");
           
        }


      


        public ActionResult LoggedIn()
        {

            int role = (int)Session["RoleId"];
            if (role == (int)TempData["RoleAdmin"])
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }

        }


        public ActionResult Logout()
        {
            Session["UtilisateurId"] = null;
            Session["Nom"] = null;
            Session["Prenom"] = null;
            Session["RoleId"] = null;
            return RedirectToAction("Login");
        }
    }
}