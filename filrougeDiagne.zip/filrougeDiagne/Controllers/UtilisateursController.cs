﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.InterfacesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class UtilisateursController : Controller
    {
        // split All Users


        public ImetiersAdmin Imetiers = new MetersImpAdmin();
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Utilisateur u)
        {
            var monUser = Imetiers.LoginUsers(u);
            if (monUser != null)
            {
                Session["UtilisateurId"] = monUser.UtilisateurId;
                Session["Nom"] = monUser.Nom;
                Session["Prenom"] = monUser.Prenom;
                Session["RoleId"] = monUser.RoleId;

                ICollection<Role> resultat = Imetiers.getRole(monUser);
                int res=0;
                foreach(var p in resultat )
                    res = p.Droit;
               
                if (res==0)
                {
                    //envoi ver l interface administrateur
                    return RedirectToAction("Index","Administrateur");
                }
                else
                {
                    //envoi ver l interface utilisateur
                    return RedirectToAction("Index","Client");
                }

            }
            return RedirectToAction("Login");
        }
    }
}