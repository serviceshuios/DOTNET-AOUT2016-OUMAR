﻿using FilRouge.Metiers.InterfacesMetiers;
using System;
using System.Collections.Generic;
using FilRouge.Metiers.ClassesMetiers;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class ProduitController : Controller
    {
        // GET: Produit
        public ImetiersAdmin Imetiers = new MetersImpAdmin();
        //public ActionResult Index()
        //{
        //    ViewBag.CatalogueId = new SelectList(Imetiers.findAllProduit(), "CatalogueId", "NomCategorie");
        //    ICollection<Produit> listesP = Imetiers.findAllProduit();
        //    return View(listesP);
        //}

        //public ActionResult AjouterProduit()
        //{
        //    //permet d'afficher un menu deroulant , viewbag est une methode permettant de communiquer avec la vue 
        //    //envoyer des informations du controlleur vers la vue a travers la fonction view()

        //    ViewBag.CategorieId = new SelectList(Imetiers.findAllCatalogue(), "CategorieId", "NomCategorie");
        //    return View();
        //}


        [HttpPost]
        public ActionResult AjouterProduit(Produit p)
        {
            Imetiers.AjouterUnProduit(p);
            return RedirectToAction("index");
        }

        public ActionResult findProductByName()
        {

            ICollection<Produit> product = Imetiers.findAll();
            return View(product);
        }
        [HttpPost]
        public ActionResult findProductByName(string Nom)
        // attention le parametre doit etre le meme que dans le parametre du text.box dans le cshtml
        {

            ICollection<Produit> res = Imetiers.findProductByName(Nom);
            return View(res);

        }

        //public ActionResult ModifierUnProduit(int id)
        //{

        //    Produit maCategorie = Imetiers.findProduit(id);
        //    ViewBag.CategorieId = new SelectList(Imetiers.findAllCategorie(), "CategorieId", "NomCategorie");
        //    return View(maCategorie);
        //}

        [HttpPost]
        public ActionResult ModifierUnProduit(Produit p)
        {

            Imetiers.ModifierUnProduit(p);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("index");
        }
        public ActionResult SupprimerUnProduit(int id)
        {
            Imetiers.SupprimerUnProduit(id);
            return RedirectToAction("index");
        }


    }
}
