﻿using FilRouge.Metiers.ClassesMetiers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Metiers.ClassesModeles
{
    public class AdministrateurModele
    {

        //protected string nom;
        //protected string prenom;
        //protected string identifiant;
        //protected string password;
        //protected string email;
        //protected DateTime dateOfBirth;

        public int AdministrateurModeleId { get; set; }
     


      
        public string Nom { get; set; }





        public string Prenom { get; set; }


        public DateTime DateOfBirth { get; set; }


        public string Identifiant { get; set; }


        public string Password { get; set; }



        public string MdpConfirm { get; set; }

     
        public string Email { get; set; }




        public int Droit { get; set; }
     
        public string NomDeRue { get; set; }
       

        public string CodePostal { get; set; }
     
        public string Ville { get; set; }
     
        public string Pays { get; set; }
    }
}