﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Metiers.ClassesModeles
{
    public class LoginModele
    {
        public int LoginModeleId { get; set; }
        public string Identifiant { get; set; }
        public string Password { get; set; }
        public int Droit { get; set; }
    }
}