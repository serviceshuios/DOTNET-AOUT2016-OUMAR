﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FilRouge.Metiers.InterfacesMetiers
{
    public interface IMetiersUsers
    {



        // methodes ajoutees deja implementées dans le code et en base

        Utilisateur AjouterUnClient( ClientModele cm);

        ICollection<Utilisateur> FindAllClient();
        Adresse AjouterUneAdresse(Adresse monAdresse);

        Adresse findAdresse(int id);

        void ModifierUneAdresse(Adresse monAdresse);
        void SupprimerUneAdresse(int monAdresse);
        ICollection<Adresse> findAllAdresse();

        ICollection<Adresse> findAdresseById(int id);

        /*****************************************************************************************************/

        Produit AjouterProduit(Produit monProduit);


      
        Commande AjouterCommande(Commande maCommande);

        LigneDeCommande AjouterLigneDeCommande(LigneDeCommande mesLignes);
        Paiement AjouterUnPaiement(Paiement monPaiement);
        Panier AjouterUnPanier(Panier monPanier);
      

        AdresseDeFacturation AjouterAdrFacturation(AdresseDeFacturation monAdrFac);
        AdresseLivraison AjouterAdrLivraison(AdresseLivraison monAdrLivr);
        Facturation AjouterFacturation(Facturation mafacture);
        CarteBancaire AjouterCarteBancaire(CarteBancaire maCb);
        Cheque AjouterCheque(Cheque monChequier);
        BonDeLivraison AjouterBonLivr(BonDeLivraison monBonDeLivr);


        Abonnement AjouterAbonnement(Abonnement monAbonnement);
        bool AjouterCarteDeFidelite();
        ProduitsConsulte AjouterunProdVu(ProduitsConsulte monProdVu);
        AvisProduit AjouterAvis(AvisProduit monAvis);


        //methodes modifier


     
        Client ModiferClient(Client monClient);     //demande




  

        LigneDeCommande ModifierLigneDeCommande();
        Panier ModifierUnPanier(Panier monPanier);
       

        AdresseDeFacturation ModifierAdrFacturation(AdresseDeFacturation monAdrFac);  //demande
        AdresseLivraison ModifierAdrLivraison(AdresseLivraison monAdrLivr);  //demande


        BonDeLivraison ModifierBonLivr(BonDeLivraison monBonDeLivr);  //demande


        Abonnement ModifierAbonnement(Abonnement monAbonnement);

        AvisProduit ModifierAvis(AvisProduit monAvis);


        //methodes supprimer


      
        Client SupprimerClient(Client monClient);  //demande
  




        Produit SupprimerProduit(Produit monProduit);
        Commande SupprimerCommande(Commande maCommande);
        LigneDeCommande SupprimerLigneDeCommande();
        Panier SupprimerUnPanier(Panier monPanier);


        Abonnement SupprimerAbonnement(Abonnement monAbonnement);
        AvisProduit SupprimerAvis(AvisProduit monAvis);


        // actions
      
        bool creationCompteClient();  //demande
        Commande PayerUneCommande();
         void  AfficheUser(Utilisateur userAAfficher);




    }
}

