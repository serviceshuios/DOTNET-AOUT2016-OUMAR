﻿using FilRouge.Dao;
using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FilRouge.Metiers.InterfacesMetiers
{

   
   public class MetiersImpUsers : IMetiersUsers   //implementation des methodes utilisateurs deja en base
    {

       public  IDao implemente = new DaoImp();


        public Utilisateur AjouterUnClient(Client monClient, ClientModele cm)
        {
            return implemente.AjouterUnClient(monClient,cm);
        }


        public ICollection<Utilisateur> FindAllClient()
        {
            return implemente.FindAllClient();
        }

        public Adresse AjouterUneAdresse(Adresse monAdresse)
        {
            return implemente.AjouterUneAdresse(monAdresse);
        }

        public Adresse findAdresse(int id)
        {
            return implemente.findAdresse(id);
        }

        public void ModifierUneAdresse(Adresse monAdresse)
        {
            implemente.ModifierUneAdresse(monAdresse);
        }

        public void SupprimerUneAdresse(int monAdresse)
        {
            implemente.SupprimerUneAdresse(monAdresse);
        }

        public ICollection<Adresse> findAllAdresse()
        {
            return implemente.findAllAdresse();
        }

        public ICollection<Adresse> findAdresseById(int id)
        {
            return implemente.findAdresseById(id);
        }

        /*****************************************************************************************************/

        public void AfficheUser(Utilisateur userAAfficher)
        {
            throw new NotImplementedException();
        }
        public Produit AjouterProduit(Produit monProduit)
        {
            return implemente.AjouterProduit(monProduit);
        }

        public Abonnement AjouterAbonnement(Abonnement monAbonnement)
        {
            throw new NotImplementedException();
        }

        

       

        public AdresseDeFacturation AjouterAdrFacturation(AdresseDeFacturation monAdrFac)
        {
            throw new NotImplementedException();
        }

        public AdresseLivraison AjouterAdrLivraison(AdresseLivraison monAdrLivr)
        {
            throw new NotImplementedException();
        }

        public AvisProduit AjouterAvis(AvisProduit monAvis)
        {
            throw new NotImplementedException();
        }

        public BonDeLivraison AjouterBonLivr(BonDeLivraison monBonDeLivr)
        {
            throw new NotImplementedException();
        }

        public CarteBancaire AjouterCarteBancaire(CarteBancaire maCb)
        {
            throw new NotImplementedException();
        }

        public bool AjouterCarteDeFidelite()
        {
            throw new NotImplementedException();
        }

        public Catalogue AjouterCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

        public Cheque AjouterCheque(Cheque monChequier)
        {
            throw new NotImplementedException();
        }

     

        public Commande AjouterCommande(Commande maCommande)
        {
            throw new NotImplementedException();
        }

        public Facturation AjouterFacturation(Facturation mafacture)
        {
            throw new NotImplementedException();
        }

        public LigneDeCommande AjouterLigneDeCommande(LigneDeCommande mesLignes)
        {
            throw new NotImplementedException();
        }


        public Promotion AjouterUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }

        public Paiement AjouterUnPaiement(Paiement monPaiement)
        {
            throw new NotImplementedException();
        }

        public Panier AjouterUnPanier(Panier monPanier)
        {
            throw new NotImplementedException();
        }

        public ProduitsConsulte AjouterunProdVu(ProduitsConsulte monProdVu)
        {
            throw new NotImplementedException();
        }

        public Role AjouterUnRole(Role unRole)
        {
            return implemente.AjouterUnRole(unRole);
        }

        public Utilisateur AjouterUnUser(Utilisateur user)
        {
            throw new NotImplementedException();
        }

        public bool creationCompteClient()
        {
            throw new NotImplementedException();
        }

        public Client ModiferClient(Client monClient)
        {
            throw new NotImplementedException();
        }

        public Abonnement ModifierAbonnement(Abonnement monAbonnement)
        {
            throw new NotImplementedException();
        }

        public Adresse ModifierAdresse(Adresse monAdresse)
        {
            throw new NotImplementedException();
        }

        public AdresseDeFacturation ModifierAdrFacturation(AdresseDeFacturation monAdrFac)
        {
            throw new NotImplementedException();
        }

        public AdresseLivraison ModifierAdrLivraison(AdresseLivraison monAdrLivr)
        {
            throw new NotImplementedException();
        }

        public AvisProduit ModifierAvis(AvisProduit monAvis)
        {
            throw new NotImplementedException();
        }

        public BonDeLivraison ModifierBonLivr(BonDeLivraison monBonDeLivr)
        {
            throw new NotImplementedException();
        }

        public LigneDeCommande ModifierLigneDeCommande()
        {
            throw new NotImplementedException();
        }

        public Panier ModifierUnPanier(Panier monPanier)
        {
            throw new NotImplementedException();
        }

        public Commande PayerUneCommande()
        {
            throw new NotImplementedException();
        }

        public Abonnement SupprimerAbonnement(Abonnement monAbonnement)
        {
            throw new NotImplementedException();
        }

        public Adresse SupprimerAdresse(Adresse monAdresse)
        {
            throw new NotImplementedException();
        }

        public AvisProduit SupprimerAvis(AvisProduit monAvis)
        {
            throw new NotImplementedException();
        }

        public Client SupprimerClient(Client monClient)
        {
            throw new NotImplementedException();
        }

        public Commande SupprimerCommande(Commande maCommande)
        {
            throw new NotImplementedException();
        }

        public LigneDeCommande SupprimerLigneDeCommande()
        {
            throw new NotImplementedException();
        }

        public Produit SupprimerProduit(Produit monProduit)
        {
            throw new NotImplementedException();
        }

        public Panier SupprimerUnPanier(Panier monPanier)
        {
            throw new NotImplementedException();
        }

      
    }
}
