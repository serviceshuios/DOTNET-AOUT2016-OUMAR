﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.InterfacesMetiers
{
   public interface ImetiersAdmin
    {

        //methode deja implementés en base de donnée 

        ICollection<Role> getRole(Utilisateur u);

        Role AjouterUnRole(Role unRole);
       

        ICollection<Role> findAllRole();

        ICollection<Role> findRoleById(int id);

        Role findRole(int id);
        Utilisateur AjouterUnClient(ClientModele cm);
       // ICollection<Client> FindAllClient();
        ICollection<Utilisateur> findAllAdministrateurs();

        ICollection<AdministrateurModele> findAllAdministrateurModele();
        Utilisateur LoginUsers(Utilisateur u);


        void ModifierUnRole(Role unRole);
        void SupprimerUnRole(int idRole);

        Adresse AjouterUneAdresse(Adresse monAdresse);
        Adresse findAdresse(int id);

        void ModifierUneAdresse(Adresse monAdresse);
        void SupprimerUneAdresse(int monAdresse);
        ICollection<Adresse> findAllAdresse();

        ICollection<Adresse> findAdresseById(int id);
        Utilisateur AjouterUnAdministrateur(Administrateur monAdmin);
        Utilisateur findAdministrateur(int id);

        void ModifierUnAdministrateur(Administrateur monAdmin);

        ICollection<Utilisateur> findAdministrateurById(int id);
        ICollection<Utilisateur> findClientById(int id);

        void SupprimerUnAdministrateur(int monAdmin);

        ICollection<ClientModele> findAllClientModele();

        Client LoginClient(Client c);
        Utilisateur findClient(int id);
        void ModifierUnClient(Client unClient);

        ICollection<Client> findAllClient();
        void SupprimerUnClient(int monClient);

        Produit AjouterUnProduit(Produit monProduit);
      
        ICollection<Produit> findAll();
        Produit findProduit(int Idproduit);
        void SupprimerUnProduit(int Idproduit);
        void ModifierUnProduit(Produit monProduit);

        ICollection<Produit> findProductByName(string nom);


        /***********************************************************************************************************/







        Catalogue AjouterCatalogue(Catalogue monCatalogue);
        Promotion AjouterUnePromotion(Promotion maPromo);

        //methode Modifier


    
      
        Catalogue MAJCatalogue(Catalogue monCatalogue);
       
        Promotion ModifierUnePromotion(Promotion maPromo);
       
      


        Produit ModifierProduit(Produit monProduit);



        //methodes supprimer


      
       
       
        Catalogue SupprimerCatalogue(Catalogue monCatalogue);
        Produit SupprimerProduit(Produit monProduit);
        Commande SupprimerCommande(Commande maCommande);

        Promotion SupprimerUnePromotion(Promotion maPromo);

        BonDeLivraison SupprimerBonLivr(BonDeLivraison monBonDeLivr);
      
    
      

    }
}
