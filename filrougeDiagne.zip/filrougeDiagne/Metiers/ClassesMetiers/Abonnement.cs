﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
   public class Abonnement            //relation 1 to many
    {

        private string formule;
        //private DateTime dateSouscription;
        //private DateTime dateDeFin;
        private decimal tarif;

        public int AbonnementId { get; set; }
        public string Formule
        {
            get { return formule; }
            set { formule = value; }
        }
        //public DateTime DateSouscription
        //{
        //    get { return dateSouscription; }
        //    set { dateSouscription = value; }
        //}
        //public DateTime DateDeFin
        //{
        //    get { return dateDeFin; }
        //    set { dateDeFin = value; }
        //}
        public decimal Tarif
        {
            get { return tarif; }
            set { tarif = value; }
        }

        public int UtilisateurId { get; set; }
        public virtual Client Client { get; set; }

    }
}
