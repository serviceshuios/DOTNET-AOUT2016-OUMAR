﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
   public class Client: Utilisateur
    {

        // attributs de la classe



      

        [Display(Name = "date du jour*")]
        [Required(ErrorMessage = "remplir la date d'arrivée")]
        public DateTime DateStartTime { get; set; }
        // private DateTime dateDeNaissance;

        [Display(Name = "anniversaire mettre a False*")]
        [Required(ErrorMessage = " fill boolean")]
        private bool anniversaire;

        [Display(Name = "remplir le numero de carte fidelite*")]
        [Required(ErrorMessage = " fill string number")]
        private string numeroCarteFidelite;

        [Display(Name = "nbPoint fidelité , mettre a zero*")]
        [Required(ErrorMessage = " set nbpoint to 20")]
        private int nbPoints;


        [Display(Name = "compteactif  mettre a true*")]
        [Required(ErrorMessage = " fill boolean")]
        private bool compteActif;


        [Display(Name = "compteasupprimer mettre a False*")]
        [Required(ErrorMessage = " fill boolean")]
        private bool compteASupprimer;


        //accesseurs de la classe

        //public DateTime DateDeNaissance
        //{
        //    get { return dateDeNaissance; }
        //    set { dateDeNaissance = value; }
        //}
      
        public Boolean Anniversaire
        {
            get { return anniversaire; }
            set { anniversaire = value; }
        }
        public string NumeroCarteFidelite
        {
            get { return numeroCarteFidelite; }
            set { numeroCarteFidelite = value; }
        }
        public int NbPoints
        {
            get { return nbPoints; }
            set { nbPoints = value; }
        }
        public bool CompteActif
        {
            get { return compteActif; }
            set { compteActif = value; }
        }
        public bool CompteASupprimer
        {
            get { return compteASupprimer; }
            set { compteASupprimer = value; }
        }

        //relation 1 to many avec commande
        public virtual ICollection<Commande> Commandes { get; set; }

        //relation 1 to many avec paiement
        public virtual ICollection<Paiement> MesPaiements { get; set; }

        //relation 1 to many avec commande
        public virtual ICollection<BonDeLivraison> MesBonsLivraison { get; set; }

        // collection d'abonnement
        public virtual ICollection<Abonnement> MesAbonnements { get; set; }


        //declaration pour la relation many to many, * vers * avec produit     
        public virtual ICollection<ProduitsConsulte> ConsulteProduits { get; set; }
        public virtual ICollection<AvisProduit> AvisProduits { get; set; }


        //public Client(string nom, string prenom, string identifiant, string password,/* DateTime dateDeNaissance*/
        //    string email, bool anniversaire, string numeroCarteFidelite, int nbPoints,
        //    bool compteActif, bool compteASupprimer) : base(nom, prenom, identifiant, password)

        //{

        //    //initialisation des variables dans la base de donnée

        //    this.nom = nom;
        //    this.prenom = prenom;
        //    this.identifiant = identifiant;
        //    this.password = password;
        //   // this.dateDeNaissance = dateDeNaissance;
        //    this.email = email;
        //    this.anniversaire = anniversaire;
        //    this.numeroCarteFidelite = numeroCarteFidelite;
        //    this.nbPoints = nbPoints;
        //    this.compteActif = compteActif;
        //    this.compteASupprimer = compteASupprimer;



        //    //on recoit l enregistrement depuis le constructeur utilisateur du menu principal 
        //    //il faut maintenant transferer les donnees vers le constructeur client et initialiser le reste des champs


        //    string str = "Data Source=localhost\\SQLExpress;Initial Catalog=GestionMetiers.ClassesDao; Integrated Security= TRUE";


        //    //// creation de notre dataadapter pour etablir la liaison avec la database de l'utilisateur
        //    SqlDataAdapter da = new SqlDataAdapter();

        //    //commande à lire en base de donnees

        //    da.SelectCommand = new SqlCommand("select * from Utilisateurs  ", new SqlConnection(str));




        //    //creation DataSet

        //    DataSet ds = new DataSet();

        //    //remplissage du DataSet avec les donnees et la structure de la base de donnee correspondant a nos utilisateurs selectionnés


        //    da.Fill(ds, "Utlisateurs");


        //    SqlCommandBuilder scb = new SqlCommandBuilder(da);
        //    scb.GetUpdateCommand();
        //    scb.GetDeleteCommand();
        //    scb.GetInsertCommand();

        //    //ajouter un utilisateur a la base grace  au dataset
        //    //          compteActif compteASupprimer
        //    DataRow mydatarow = ds.Tables[0].NewRow();
        //    mydatarow["Nom"] = nom;
        //    mydatarow["Prenom"] = prenom;
        //    mydatarow["Identifiant"] = identifiant;
        //    mydatarow["Password"] = password;
        //   // mydatarow["DateDeNaissance"] = dateDeNaissance;

 
        //    mydatarow["Email"] = email;
        //    mydatarow["Anniversaire"] = anniversaire;
        //    mydatarow["CompteActif"] = compteActif;

        //    mydatarow["NumeroCarteFidelite"] = numeroCarteFidelite;
        //    mydatarow["NbPoints"] = nbPoints;


        //    // ajouter la ligne au dataset
        //    ds.Tables[0].Rows.Add(mydatarow);

        //    //mettre a jour la BDD

        //    da.Update(ds.Tables[0]);
        //    Console.Write("personne ajoutee");

        //    //message à l'utilisateur


        //}



        }
}
