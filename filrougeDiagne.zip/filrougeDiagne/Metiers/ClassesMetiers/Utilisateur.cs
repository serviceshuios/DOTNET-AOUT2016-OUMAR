﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{


    public class Utilisateur
    {
        protected string nom;
        protected string prenom;
        protected string identifiant;
        protected string password;
        protected string email;
       


        public int UtilisateurId { get; set; }


        [Display(Name = "Nom*")]
        [MaxLength(15, ErrorMessage = "la saisie est trop longue , max 15 caracteres")]
        [Required(ErrorMessage = "remplir le nom")]
        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }


       

        [Display(Name = "Prenom*")]
        [MaxLength(20, ErrorMessage = "la saisie est trop longue , max 20  caracteres")]
        [MinLength(5, ErrorMessage = "la saisie est trop courte , min 5 caracteres")]
        [Required(ErrorMessage = "remplir le Prenom")]
        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }


        [Display(Name = "DatedeNaissance*")]
        [Required(ErrorMessage = "remplir la date de naissance")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Range(typeof(DateTime), "1/1/1970", "1 / 1 / 2010", ErrorMessage = "date non valide")]
        public DateTime DateOfBirth { get; set; }


        [Display(Name = "Identifiant*")]
        [Required(ErrorMessage = "remplir le login")]
        [MaxLength(12, ErrorMessage = "la saisie est trop longue , max 12  caracteres")]
        public string Identifiant
        {
            get { return identifiant; }
            set { identifiant = value; }
        }

        [Display(Name = "Password*")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "remplir le mot de passe")]
        public string Password
        {
            get { return password; }
            set { password = value; }
        }


        [Display(Name = "Confirmation Password*")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "mot de passes saisi non identique")]
        public string MdpConfirm { get; set; }

        [Display(Name = "Email*")]
        [Required(ErrorMessage = "remplir l'email")]
        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        [Display(Name = "Role*")]
        [Required(ErrorMessage = "remplir le champ role")]
        public int RoleId { get; set; }
        public virtual Role Role { get; set; }

        [Display(Name = "Adresse*")]
        [Required(ErrorMessage = "remplir le champ adresse ")]
        public int AdresseId { get; set; }
        public virtual Adresse Adresse { get; set; }




        //public Utilisateur(string nom, string prenom, string identifiant, string password)
        //{
        //    UtilisateurId = incr++;
        //    this.nom = nom;
        //    this.prenom = prenom;
        //    this.identifiant = identifiant;
        //    this.password = password;
        //}


        // methodes connexion utilisateur et administrateur






        /*******************************************************************************************/



        //public bool authentification(Utilisateur user)
        //{
        //    string str = "Data Source=localhost\\SQLExpress;Initial Catalog=BDDUtilisateurs; Integrated Security= TRUE";


        //    //// creation de notre dataadpater pour etablir la liaison avec la database de l'utilisateur
        //    SqlDataAdapter da = new SqlDataAdapter();

        //    //commande à lire en base de donnees

        //    da.SelectCommand = new SqlCommand("select * from Utilisateurs  ", new SqlConnection(str));




        //    //creation DataSet

        //    DataSet ds = new DataSet();

        //    //remplissage du DataSet avec les donnees et la structure de la base de donnee correspondant a nos utilisateurs selectionnés


        //    da.Fill(ds, "Utlisateurs");


        //    SqlCommandBuilder scb = new SqlCommandBuilder(da);
        //    scb.GetUpdateCommand();
        //    scb.GetDeleteCommand();
        //    scb.GetInsertCommand();



        //    //on vient lire notre identifiant dans la base ligne par ligne en selectionnant la colonne identifiant

        //    foreach (DataRow dr in ds.Tables[0].Rows)
        //    {
        //        if (Convert.ToString(dr["Identifiant"]) == user.Identifiant)
        //        {

        //            foreach (DataRow datapassword in ds.Tables[0].Rows)   // idem avec datapassword 
        //            {
        //                if (Convert.ToString(datapassword["Password"]) == user.Password)
        //                    return true;         // ca match on retourne true
        //            }

        //        }

        //    }

        //    return false;          // pas d'identifiant qui match ou pas de mot de passe associé.
        //}


        ////public string authentification()
        ////{
        ////    initConnexion();
        ////    string str = "Data Source=localhost\\SQLExpress;Initial Catalog=BDDUtilisateurs; Integrated Security= TRUE";


        ////    creation de notre dataadpater
        ////    SqlDataAdapter da = new SqlDataAdapter();

        ////    commande à lire en base de donnees

        ////    da.SelectCommand = new SqlCommand("select * from Utilisateurs nom like @param ", new SqlConnection(str));
        ////    SqlParameter param = new SqlParameter("@param", identifiant);
        ////    da.SelectCommand.Parameters.Add(param);


        ////    creation DataSet

        ////    DataSet ds = new DataSet();

        ////    remplissage du DataSet avec les donnees et la structure de la base de donnee

        ////    da.Fill(ds, "personne");
        ////    if (ds.Tables[0].Select())


        ////        return "";

        ////}  // fonction permettant l authentification 

    }
}

