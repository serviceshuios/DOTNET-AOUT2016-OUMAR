﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
   public class Catalogue                        // 1 vers *, produit
    {
        public int CatalogueId { get; set; }   
        public virtual ICollection<Produit> Produits { get; set; }



 


    }
}
