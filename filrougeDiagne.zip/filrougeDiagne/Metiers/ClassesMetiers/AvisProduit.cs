﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
   public class AvisProduit            // relation manytomany entre ^produit et client
    {
       
        [Key, Column(Order = 0)]
        public int UtilisateurId { get; set; }

        [Key, Column(Order = 1)]
        public int ProduitId { get; set; }

        public virtual Client Client { get; set; }
        public virtual Produit Produit { get; set; }

        private string note;

        public string Note
        {
            get { return note; }
            set { note = value; }
        }


        public AvisProduit(string note, int numClient, int numProduit)
        {
            this.note = note;
            UtilisateurId = numClient;
            ProduitId = numProduit;
        }
    }
}
