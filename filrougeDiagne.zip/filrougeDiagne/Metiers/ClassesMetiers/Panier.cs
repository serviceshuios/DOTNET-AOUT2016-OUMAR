﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{ 
  public class Panier        // relation 1 to many avec panier
    {

        private decimal prixTotal;
        public int  PanierId  { get; set; }
        public int  NbProduit { get; set; }
        public virtual ICollection<LigneDeCommande> LigneDeMonPanier { get; set; }


        public decimal PrixTotal
        {
            get {return prixTotal; }
            set {prixTotal=value; }
        }

    }
}
