﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Promotion
    {

        private decimal promo;

        public int PromotionId { get; set; }
        public decimal Promo
        {
            get {return promo; }
            set {promo=value; }

        }

       
        public virtual ICollection<Produit> ProduitEnPromo{ get; set; }

        public Promotion( decimal promo)
        {
            this.promo = promo;
        }
    }
}
