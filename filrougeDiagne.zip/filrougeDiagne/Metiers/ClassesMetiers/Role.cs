﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Role
    {
        public int RoleId { get; set; }
        public int Droit { get; set; }



        public virtual ICollection<Utilisateur> RoleUtilisateur { get; set; }



      


    }
}
